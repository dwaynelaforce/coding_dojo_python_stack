$(document).ready(function () {
    alert("Javascript is running!");

















});