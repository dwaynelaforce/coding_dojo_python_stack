from django.apps import AppConfig


class LoginRegAppConfig(AppConfig):
    name = 'login_reg_app'
