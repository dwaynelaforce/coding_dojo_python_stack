from django.db import models

# Create your models here.
class Show(models.Model):
    title = models.CharField(max_length=55)
    network = models.CharField(max_length=55)
    release_date = models.DateField(blank=True)
    desc = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)